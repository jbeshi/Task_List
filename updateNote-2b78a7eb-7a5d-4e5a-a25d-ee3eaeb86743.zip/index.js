console.log('Loading event');
var AWS = require('aws-sdk');
var dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context) {
    console.log("Request received:\n", JSON.stringify(event));
    console.log("Context received:\n", JSON.stringify(context));

    var tableName = "notes";
    
    var params = {
  Key:{
        id: event.id
    },
    UpdateExpression: "set description=:description, editors=:editors, viewers=:viewers",
    ExpressionAttributeValues:{
        ":description":event.description,
        ":viewers":event.viewers,
        ":editors":event.editors
    },
    ReturnValues:"UPDATED_NEW",
  TableName: tableName
 };

    
    dynamodb.update(params, function(err, data) {
            if (err) {
                context.fail('ERROR: Dynamo failed: ' + err);
            } else {
                console.log('Dynamo Success: ' + JSON.stringify(data, null, '  '));
                context.succeed(data);
            }
        });
}