console.log('Loading event');

var aws = require('aws-sdk');

var ses = new aws.SES({
   region: 'us-east-1' 
});

var dynamodb = new aws.DynamoDB.DocumentClient();

exports.handler = function(event, context) {
    console.log("Request received:\n", JSON.stringify(event));
    console.log("Context received:\n", JSON.stringify(context));

    var tableName = "tasks";
    
    var params = {
        TableName: tableName
    }
    
    dynamodb.scan(params, function(err, data) {
            if (err) {
                context.fail('ERROR: Dynamo failed: ' + err);
            } else {
                console.log('Dynamo Success: ' + JSON.stringify(data, null, '  '));
                for(var item in data.Items) {
                    console.log('Item is: ' + JSON.stringify(data.Items[item], null, '  '));
                    if(data.Items[item].completed === undefined  || data.Items[item].completed === null || data.Items[item].completed === "") {
                        console.log("Email to:", data.Items[item].user);
    var eParams = {
        Destination: {
            ToAddresses: [ data.Items[item].user ]
        },
        Message: {
            Body: {
                Text: {
                    Data: "The task \"" +  data.Items[item].description + "\" has not been completed yet"
                }
            },
            Subject: {
                Data: "Uncompleted Task"
            }
        },
        Source: "f1savant@gmail.com"
    };

    console.log('===SENDING EMAIL===');
    var email = ses.sendEmail(eParams, function(err, data){
        if(err) console.log(err);
        else {
            console.log("===EMAIL SENT===");
            console.log(data);
            context.succeed(event);

        }
    });
    console.log("EMAIL CODE END");
   // console.log('EMAIL: ', email); 
    }
                }
            }
        });
}
