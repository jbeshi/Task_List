console.log('Loading event');
var AWS = require('aws-sdk');
var dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context) {
    console.log("Request received:\n", JSON.stringify(event));
    console.log("Context received:\n", JSON.stringify(context));


    var user = "";

    if (event.params.querystring !== null && event.params.querystring !== undefined) {
        if (event.params.querystring.user !== undefined && event.params.querystring.user !== null && event.params.querystring.user !== "") {
            console.log("Received user: " + event.params.querystring.user);
            user = event.params.querystring.user;
        }

    }
    console.log("User is:\n", user);

    var tableName = "notes";
    
    var params = {
    TableName: tableName,
    ExpressionAttributeNames: {
         "#editor": "editors",
         "#viewer": "viewers"
    },
    ExpressionAttributeValues: {
         ":editor": user,
         ":viewer": user
    },
    FilterExpression: "contains(#editor,  :editor) OR contains(#viewer,  :viewer)"
  }
    
    dynamodb.scan(params, function(err, data) {
            if (err) {
                context.fail('ERROR: Dynamo failed: ' + err);
            } else {
                console.log('Dynamo Success: ' + JSON.stringify(data, null, '  '));
                context.succeed(data);
            }
        });
}