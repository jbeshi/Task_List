console.log('Loading event');
var AWS = require('aws-sdk');
var dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context) {
    console.log("Request received:\n", JSON.stringify(event));
    console.log("Context received:\n", JSON.stringify(context));

    var tableName = "tasks";
    
    var params = {
  Item: {
   user: event.user, 
   description: event.description, 
   priority: event.priority, 
   completed: event.completed
  }, 
  ReturnConsumedCapacity: "TOTAL", 
  TableName: tableName
 };

    
    dynamodb.put(params, function(err, data) {
            if (err) {
                context.fail('ERROR: Dynamo failed: ' + err);
            } else {
                console.log('Dynamo Success: ' + JSON.stringify(data, null, '  '));
                context.succeed(data);
            }
        });
}